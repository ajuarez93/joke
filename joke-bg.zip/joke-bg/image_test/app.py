from PIL import Image, ImageDraw, ImageFont
import requests
from io import BytesIO

import textwrap


logo = "logo_url"
human = "logo_url"
robot = "logo_ur"

logo_response = requests.get(logo)
logo_bytes = Image.open(BytesIO(logo_response.content))
resized_logo = logo_bytes.resize((50, 50))


human_response = requests.get(human)
human_bytes = Image.open(BytesIO(human_response.content))
resized_human = human_bytes.resize((20, 20))

robot_response = requests.get(robot)
robot_bytes = Image.open(BytesIO(robot_response.content))
resized_robot = robot_bytes.resize((20, 20))

setup = "A male developer often gets called as a Dev, then what would you call a female developer?"
punchline = "A full one, in case he gets thirsty, and an empty one, in case he doesn’t."
generate = "ai"
type_ = "GENERAL"

light = "Roboto-Light.ttf"
bold = 'Roboto-Bold.ttf'

# Resize the image.


# Create a new image with white background
image = Image.new('RGB', (400, 400), 'white')
draw = ImageDraw.Draw(image)
image.paste(resized_logo, (20 , 10))

draw.text((80, 22), "Joke Funny", "#9d5353", ImageFont.truetype(bold, 24))

draw.rounded_rectangle([25, 75, 375, 340], 5, fill='#51171c')

wrapped_setup = textwrap.fill(setup, width=35)
draw.text((50, 120), wrapped_setup, "white", ImageFont.truetype(bold, 19))

wrapped_punchline = textwrap.fill(punchline, width=45)
draw.text((50, 220), wrapped_punchline, "white", ImageFont.truetype(light, 15))
if generate == "manual":
    image.paste(resized_human, (20 , 360))
    draw.text((50, 363), "Created by a developer", "#9d5353", ImageFont.truetype(light, 12))
else:
    image.paste(resized_robot, (20 , 360))
    draw.text((50, 363), "Created by a robot", "#9d5353", ImageFont.truetype(light, 12))
    



# Save the image to a file
image.save('res.png')

