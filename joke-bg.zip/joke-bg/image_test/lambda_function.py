import json
import boto3
import os
import uuid
from datetime import datetime
from PIL import Image, ImageDraw, ImageFont
import requests
from io import BytesIO
import textwrap
from io import BytesIO

aws_access_key_id = os.environ.get('aws_access_key_id')
aws_secret_access_key = os.environ.get('aws_secret_access_key')
TABLE_NAME = "joke-funny"
TABLE_NAME_LOG = "joke-funny-log"
# Initialize a boto3 client for DynamoDB

dynamodb_client = boto3.client(
    'dynamodb', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key
)

s3 = boto3.client(
    's3', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key
)


def lambda_handler(event, context):
    if 'body' in event:
        body = json.loads(event['body'])
    else:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': "Missing data to send"})
        }

    required_params = ['setup', 'punchline', 'joke_uuid', 'generate']
    for param in required_params:
        if param not in body:
            return {
                "statusCode": 400,
                "body": json.dumps({'error': "Missing data to send"})
            }

    action = 'generate_image'
    user = "not_user"
    setup = body['setup']
    punchline = body['punchline']
    generate = body['generate']
    joke_uuid = body['joke_uuid']

    try:

        current_date = datetime.now()
        date_string = current_date.isoformat()

        logo = "logo_ur"
        human = "logo_ur"
        robot = "logo_ur"

        logo_response = requests.get(logo)
        logo_bytes = Image.open(BytesIO(logo_response.content))
        resized_logo = logo_bytes.resize((50, 50))

        human_response = requests.get(human)
        human_bytes = Image.open(BytesIO(human_response.content))
        resized_human = human_bytes.resize((20, 20))

        robot_response = requests.get(robot)
        robot_bytes = Image.open(BytesIO(robot_response.content))
        resized_robot = robot_bytes.resize((20, 20))

        light = "Roboto-Light.ttf"
        bold = 'Roboto-Bold.ttf'

        image = Image.new('RGB', (400, 400), 'white')
        draw = ImageDraw.Draw(image)
        image.paste(resized_logo, (20, 10))

        draw.text((80, 22), "Joke Funny", "#9d5353",
                  ImageFont.truetype(bold, 24))

        draw.rounded_rectangle([25, 75, 375, 340], 5, fill='#51171c')

        wrapped_setup = textwrap.fill(setup, width=35)
        draw.text((50, 120), wrapped_setup, "white",
                  ImageFont.truetype(bold, 19))

        wrapped_punchline = textwrap.fill(punchline, width=45)
        draw.text((50, 220), wrapped_punchline, "white",
                  ImageFont.truetype(light, 15))
        if generate == "manual":
            image.paste(resized_human, (20, 360))
            draw.text((50, 363), "Created by a developer",
                      "#9d5353", ImageFont.truetype(light, 12))
        else:
            image.paste(resized_robot, (20, 360))
            draw.text((50, 363), "Created by a robot",
                      "#9d5353", ImageFont.truetype(light, 12))

        in_memory_file = BytesIO()
        image.save(in_memory_file, format='JPEG')
        in_memory_file.seek(0)

        bucket_name = 'joke-funny-assets'  # Your S3 bucket name
        # Object name in S3 (path and filename)
        object_name = f'images/{joke_uuid}.jpg'
        image_url = f'logo_url/audios/{joke_uuid}.jpg'

        # Upload the bytes to S3
        s3.upload_fileobj(in_memory_file, bucket_name, object_name)

        # Close the BytesIO object
        in_memory_file.close()

        key = {'joke_uuid': {'S': joke_uuid}}

        dynamodb_client.update_item(
            Key=key,
            TableName=TABLE_NAME,
            UpdateExpression="SET image_url = :image_url, date_image_update = :date_image_update",
            ExpressionAttributeValues={
                ':image_url': {'S': image_url},
                ':date_image_update': {'S': str(date_string)},
            }
        )

        ni = {
            'joke_log_uuid': {'S': str(uuid.uuid4())},
            'joke_uuid': {'S': str(joke_uuid)},
            'action': {'S': str(action)},
            'user': {'S': str(user)},
            'date_string': {'S': str(date_string)},
        }
        r = dynamodb_client.put_item(
            TableName=TABLE_NAME_LOG,
            Item=ni
        )

        return {
            'statusCode': 200,
            'body': json.dumps(r)
        }
    except Exception as e:
        print(e)
        return {
            'statusCode': 404,
            'body': json.dumps('Item not found')
        }
