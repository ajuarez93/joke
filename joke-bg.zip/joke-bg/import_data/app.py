import os
import json
import boto3
from dotenv import load_dotenv
import uuid

load_dotenv()


aws_access_key_id = os.environ.get('aws_access_key_id')
aws_secret_access_key = os.environ.get('aws_secret_access_key')
# Initialize a DynamoDB client
dynamodb = boto3.client('dynamodb', aws_access_key_id=aws_access_key_id,
                        aws_secret_access_key=aws_secret_access_key, region_name='us-east-1')

table_name = 'joke-funny'


# Load JSON data from a file
with open('index.json', 'r') as file:
    data = json.load(file)

print(data)

for item in data:
    ni = {
        'type': {'S': str(item["type"])},
        'setup': {'S': str(item["setup"])},
        'punchline': {'S': str(item["punchline"])},
        'generate': {'S': str("manual")},
        'joke_uuid': {'S': str(uuid.uuid4())},
    }
    response = r = dynamodb.put_item(
        TableName=table_name,
        Item=ni
    )
    print("Item added:", response)
