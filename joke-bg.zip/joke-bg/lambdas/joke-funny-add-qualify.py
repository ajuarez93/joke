import json
import boto3
import os
import uuid
from datetime import datetime

aws_access_key_id = os.environ.get('aws_access_key_id')
aws_secret_access_key = os.environ.get('aws_secret_access_key')
TABLE_NAME = "joke-funny"
TABLE_NAME_LOG = "joke-funny-log"
# Initialize a boto3 client for DynamoDB

dynamodb_client = boto3.client(
    'dynamodb', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key)


def remove_dynamo_types(items):
    # Process each item in the list
    clean_items = []
    for item in items:
        clean_item = {}
        for key, value in item.items():
            # Extract the actual value from the DynamoDB data type
            clean_item[key] = next(iter(value.values()))
        clean_items.append(clean_item)
    return clean_items


def get_quality(joke_uuid):
    response = dynamodb_client.scan(
        TableName=TABLE_NAME,
        FilterExpression='joke_uuid = :joke_uuid',
        ProjectionExpression='qualify_ok, qualify_nok',
        ExpressionAttributeValues={
            ':joke_uuid': {'S': str(joke_uuid)}
        },
    )
    items = response["Items"]

    return remove_dynamo_types(items)


def lambda_handler(event, context):
    if 'body' in event:
        body = json.loads(event['body'])
    else:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': "Missing data to send"})
        }

    required_params = ['qualify', 'joke_uuid']
    for param in required_params:
        if param not in body:
            return {
                "statusCode": 400,
                "body": json.dumps({'error': "Missing data to send"})
            }

    action = 'qualify_joke'
    user = "not_user"
    qualify = body['qualify']
    joke_uuid = body['joke_uuid']

    try:

        current_date = datetime.now()
        date_string = current_date.isoformat()

        res = get_quality(joke_uuid)
        if len(res) < 1:
            return {
                'statusCode': 404,
                'body': json.dumps(res)
            }
            
        r = res[0]
        
        qualify_ok = "0"
        if "qualify_ok" in r:
            qualify_ok = r['qualify_ok']
        
        qualify_nok = "0"
        if "qualify_nok" in r:
            qualify_nok = r['qualify_nok']
        
        if qualify == "ok":
            qualify_ok = int(qualify_ok) + 1
        else:
            qualify_nok = int(qualify_nok) + 1
        
        key = {'joke_uuid': {'S': joke_uuid}}

        dynamodb_client.update_item(
            Key=key,
            TableName=TABLE_NAME,
            UpdateExpression="SET qualify_ok = :qualify_ok, qualify_nok = :qualify_nok",
            ExpressionAttributeValues={
                ':qualify_ok': {'S': str(qualify_ok)},
                ':qualify_nok': {'S': str(qualify_nok)},
            }
        )
        
        ni = {
            'joke_log_uuid': {'S': str(uuid.uuid4())},
            'joke_uuid': {'S': str(joke_uuid)},
            'action': {'S': str(action)},
            'user': {'S': str(user)},
            'date_string': {'S': str(date_string)},
        }
        r = dynamodb_client.put_item(
            TableName=TABLE_NAME_LOG,
            Item=ni
        )

        return {
            'statusCode': 200,
            'body': json.dumps(r)
        }
    except Exception as e:
        print(e)
        return {
            'statusCode': 404,
            'body': json.dumps('Item not found')
        }
