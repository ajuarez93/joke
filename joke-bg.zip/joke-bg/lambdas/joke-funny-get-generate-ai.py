import json
import boto3
import openai
import os
import uuid
from datetime import datetime

openai.api_key = os.environ.get('api_key')
aws_access_key_id = os.environ.get('aws_access_key_id')
aws_secret_access_key = os.environ.get('aws_secret_access_key')
TABLE_NAME = "joke-funny-log"
# Initialize a boto3 client for DynamoDB

dynamodb_client = boto3.client(
    'dynamodb', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key)

def send_prompt(prompt, model_engine):
    data = [{"role": "user", "content": prompt}]

    response = openai.ChatCompletion.create(
        model=model_engine,
        messages=data
    )
    message = response.choices[0].message
    return message

def lambda_handler(event, context):
    
    prompt = """
        You must act like an expert eater,
        Generate 10 short programming jokes, following the following structure
        [
            {
                "setup": "Did you hear about the new restaurant on the moon?",
                "punchline": "The food is great, but there’s just no atmosphere.",
                "type": "general"
            },
            {
                "setup": "What is the leading cause of dry skin?",
                "punchline": "Towels",
                "joke_uuid": "29858e72-22a9-4476-a3c0-fea8769f8c4f",
                "type": "general"
            }
        ]
        
        Do not explain or describe your response. DON NOT include apoloyize. DON NOT include sorry... DO NOT Include aditional text only response with the ARRAY
        
    """
    
    try:
        # Fetch the item from DynamoDB
        user = "not_user"
        
        current_date = datetime.now()
        date_string = current_date.isoformat()
        
        model_engine = "gpt-3.5-turbo"
        response = send_prompt(prompt, model_engine)
        
        ni = {
            'joke_log_uuid': {'S': str(uuid.uuid4())},
            'joke_uuid': {'S': str("")},
            'action': {'S': str("generate_joke_ai")},
            'user': {'S': str(user)},
            'date_string': {'S': str(date_string)},
        }
        dynamodb_client.put_item(
            TableName=TABLE_NAME,
            Item=ni
        )
        
        return {
            'statusCode': 200,
            'body': json.dumps(json.loads(response))
        }
        
    except Exception as e:
        print(e)
        return {
            'statusCode': 500,
            'body': e
        }

