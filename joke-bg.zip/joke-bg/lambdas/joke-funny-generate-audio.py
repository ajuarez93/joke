import json
import boto3
import os
import uuid
from datetime import datetime
from gtts import gTTS
from io import BytesIO

aws_access_key_id = os.environ.get('aws_access_key_id')
aws_secret_access_key = os.environ.get('aws_secret_access_key')
TABLE_NAME = "joke-funny"
TABLE_NAME_LOG = "joke-funny-log"
# Initialize a boto3 client for DynamoDB

dynamodb_client = boto3.client(
    'dynamodb', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key
)

s3 = boto3.client(
    's3', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key
)


def lambda_handler(event, context):
    if 'body' in event:
        body = json.loads(event['body'])
    else:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': "Missing data to send"})
        }

    required_params = ['setup', 'punchline', 'joke_uuid']
    for param in required_params:
        if param not in body:
            return {
                "statusCode": 400,
                "body": json.dumps({'error': "Missing data to send"})
            }

    action = 'generate_audio'
    user = "not_user"
    setup = body['setup']
    punchline = body['punchline']
    joke_uuid = body['joke_uuid']

    try:

        current_date = datetime.now()
        date_string = current_date.isoformat()

        language = 'en'  # Language in which you want to convert

        my_text = setup + "                             " + punchline
        # Create a gTTS object
        tts = gTTS(text=my_text, lang=language, slow=False)
        mp3_fp = BytesIO()
        tts.write_to_fp(mp3_fp)
        mp3_fp.seek(0)

        bucket_name = 'joke-funny-assets'  # Your S3 bucket name
        # Object name in S3 (path and filename)
        object_name = f'audios/{joke_uuid}.mp3'
        audio_url = f'logo_url/audios/{joke_uuid}.mp3'

        # Upload the bytes to S3
        s3.upload_fileobj(mp3_fp, bucket_name, object_name)

        # Close the BytesIO object
        mp3_fp.close()
        
        
        key = {'joke_uuid': {'S': joke_uuid}}

        dynamodb_client.update_item(
            Key=key,
            TableName=TABLE_NAME,
            UpdateExpression="SET audio_url = :audio_url, date_update = :date_update",
            ExpressionAttributeValues={
                ':audio_url': {'S': audio_url},
                ':date_update': {'S': str(date_string)},
            }
        )

        ni = {
            'joke_log_uuid': {'S': str(uuid.uuid4())},
            'joke_uuid': {'S': str(joke_uuid)},
            'action': {'S': str(action)},
            'user': {'S': str(user)},
            'date_string': {'S': str(date_string)},
        }
        r = dynamodb_client.put_item(
            TableName=TABLE_NAME_LOG,
            Item=ni
        )

        return {
            'statusCode': 200,
            'body': json.dumps(r)
        }
    except Exception as e:
        print(e)
        return {
            'statusCode': 404,
            'body': json.dumps('Item not found')
        }
