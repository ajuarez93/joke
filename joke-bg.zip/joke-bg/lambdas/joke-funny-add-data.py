import json
import boto3
import os
import uuid
from datetime import datetime

aws_access_key_id = os.environ.get('aws_access_key_id')
aws_secret_access_key = os.environ.get('aws_secret_access_key')
TABLE_NAME = "joke-funny"
TABLE_NAME_LOG = "joke-funny-log"
# Initialize a boto3 client for DynamoDB

dynamodb_client = boto3.client(
    'dynamodb', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key)


def lambda_handler(event, context):
    if 'body' in event:
        body = json.loads(event['body'])
    else:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': "Missing data to send"})
        }

    required_params = ['setup', 'punchline', 'type', 'generate']
    for param in required_params:
        if param not in body:
            return {
                "statusCode": 400,
                "body": json.dumps({'error': "Missing data to send"})
            }

    action = 'add_joke'
    user = "not_user"
    setup = body['setup']
    punchline = body['punchline']
    type_ = body['type']
    generate = body['generate']
    joke_uuid = uuid.uuid4()
    if 'joke_uuid' in body:
        joke_uuid = body['joke_uuid']
        action = 'update_joke'

    try:

        current_date = datetime.now()
        date_string = current_date.isoformat()

        ni = {
            'type': {'S': str(type_)},
            'setup': {'S': str(setup)},
            'punchline': {'S': str(punchline)},
            'generate': {'S': str(generate)},
            'joke_uuid': {'S': str(joke_uuid)},
            'date_string': {'S': str(date_string)},
        }
        r = dynamodb_client.put_item(
            TableName=TABLE_NAME,
            Item=ni
        )

        ni = {
            'joke_log_uuid': {'S': str(uuid.uuid4())},
            'joke_uuid': {'S': str(joke_uuid)},
            'action': {'S': str(action)},
            'user': {'S': str(user)},
            'date_string': {'S': str(date_string)},
        }
        r = dynamodb_client.put_item(
            TableName=TABLE_NAME_LOG,
            Item=ni
        )

        return {
            'statusCode': 200,
            'body': json.dumps(r)
        }
    except Exception as e:
        print(e)
        return {
            'statusCode': 404,
            'body': json.dumps('Item not found')
        }
