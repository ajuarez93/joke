import json
import boto3
import os

aws_access_key_id = os.environ.get('aws_access_key_id')
aws_secret_access_key = os.environ.get('aws_secret_access_key')
TABLE_NAME = "joke-funny"
# Initialize a boto3 client for DynamoDB

dynamodb_client = boto3.client(
    'dynamodb', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key)

def remove_dynamo_types(items):
    # Process each item in the list
    clean_items = []
    for item in items:
        clean_item = {}
        for key, value in item.items():
            # Extract the actual value from the DynamoDB data type
            clean_item[key] = next(iter(value.values()))
        clean_items.append(clean_item)
    return clean_items


def get_all():
    response = dynamodb_client.scan(
        TableName=TABLE_NAME,
        FilterExpression='joke_uuid <> :joke_uuid',
        ExpressionAttributeValues={
            ':joke_uuid': {'S': str(0)}
        },
    )
    items = response["Items"]
   
    return remove_dynamo_types(items)


def lambda_handler(event, context):
    
   
    
    try:
        # Fetch the item from DynamoDB
        data = get_all()
    except Exception as e:
        print(e)
        return {
            'statusCode': 500,
            'body': json.dumps('Error fetching item from DynamoDB')
        }
    
  
    
    if data:
        # Return the retrieved item
        return {
            'statusCode': 200,
            'body': json.dumps(data)
        }
    else:
        return {
            'statusCode': 404,
            'body': json.dumps('Item not found')
        }
