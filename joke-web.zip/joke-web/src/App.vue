<template>
  <div class="flex items-center bg-[#ede6db] min-h-screen flex-col">
    <div
      class="container flex flex-col min-h-screen relative px-4 lg:px-0 mb-4"
    >
      <div
        class="bg-[#ede6db] fixed w-screen px-4 lg:px-0 top-0 py-6 left-0 flex items-center justify-center z-40"
      >
        <div class="container flex flex-row justify-between items-center">
          <div class="flex flex-col lg:flex-row items-center gap-2">
            <img src="./assets/joke.png" alt="Joke Funny" />
            <h1 class="text-lg font-bold text-[#51171c]">Joke Funny</h1>
          </div>

          <div class="flex flex-row gap-2">
            <button
              class="bg-[#9d5353] text-white px-4 py-2 text-xs rounded-full"
              @click="newJokeModal"
            >
              New Joke
            </button>

            <button
              class="bg-[#9d5353] text-white px-4 py-2 text-xs rounded-full"
              @click="openModalJokeAI"
            >
              Generate Joke with AI
            </button>
          </div>
        </div>
      </div>

      <div class="bg-[#350000] p-4 mt-36 lg:mt-28 rounded-lg">
        <div class="text-white font-bold">Filters</div>
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-2">
          <div class="flex flex-col">
            <label for="Setup" class="text-sm text-white">Setup</label>
            <input
              v-model="setupText"
              name="Setup"
              type="text"
              class="w-full text-sm rounded py-1 px-2"
            />
          </div>
          <div class="flex flex-col">
            <label for="Punchline" class="text-sm text-white">Punchline</label>
            <input
              v-model="punchlineText"
              name="Punchline"
              type="text"
              class="w-full text-sm rounded py-1 px-2"
            />
          </div>
          <div class="flex flex-col">
            <label for="type " class="text-sm text-white">Type</label>
            <select
              v-model="typeSelect"
              class="w-full text-sm rounded py-1 px-2"
            >
              <option v-for="c in categoryJokes" :value="c">{{ c }}</option>
            </select>
          </div>
          <div class="flex flex-col">
            <label for="type " class="text-sm text-white">Generate</label>
            <select
              v-model="generateSelect"
              class="w-full text-sm rounded py-1 px-2"
            >
              <option value="manual">Manual</option>
              <option value="ai">IA</option>
            </select>
          </div>
        </div>
        <div class="w-full flex justify-end">
          <button
            class="bg-[#c22929] text-white px-4 py-2 mt-2 text-xs rounded-full"
            @click="clearFilter"
          >
            Clear Filters
          </button>
        </div>
      </div>
      <div class="flex-1 flex flex-col gap-2">
        <div class="pt-8 flex flex-col lg:flex-row justify-between">
          <div class="flex items-center gap-2">
            <button
              class="bg-[#9d5353] text-white px-4 py-2 text-xs rounded-full flex flex-row justify-center gap-2"
              @click="loadJokes"
            >
              <svg
                height="18px"
                viewBox="0 0 512 512"
                width="18px"
                xmlns="http://www.w3.org/2000/svg"
              >
                <title />
                <path
                  d="M434.67,285.59v-29.8C434.67,157.06,354.43,77,255.47,77a179,179,0,0,0-140.14,67.36m-38.53,82v29.8C76.8,355,157,435,256,435a180.45,180.45,0,0,0,140-66.92"
                  style="
                    fill: none;
                    stroke: #fff;
                    stroke-linecap: round;
                    stroke-linejoin: round;
                    stroke-width: 32px;
                  "
                />
                <polyline
                  points="32 256 76 212 122 256"
                  style="
                    fill: none;
                    stroke: #fff;
                    stroke-linecap: round;
                    stroke-linejoin: round;
                    stroke-width: 32px;
                  "
                />
                <polyline
                  points="480 256 436 300 390 256"
                  style="
                    fill: none;
                    stroke: #fff;
                    stroke-linecap: round;
                    stroke-linejoin: round;
                    stroke-width: 32px;
                  "
                />
              </svg>
              Sync
            </button>
            <span class="font-bold text-[#51171c]">Results</span>
            <span class="text-[#51171c]">({{ filteredJokes.length }})</span>
          </div>

          <div class="flex flex-row gap-2 items-center justify-end">
            <span class="text-xs">Show:</span>
            <select v-model="itemsPerPage" class="text-xs rounded py-1">
              <option :value="5">5</option>
              <option :value="10">10</option>
              <option :value="20">20</option>
              <option :value="30">30</option>
            </select>
            <paginator
              :total-items="filteredJokes.length"
              :items-per-page="itemsPerPage"
              @page-changed="handlePageChange"
            />

            <button class="p-2 flex items-center gap-1" @click="changeOrder">
              <svg
                height="18px"
                version="1.1"
                viewBox="0 0 14 18"
                width="14px"
                xmlns="http://www.w3.org/2000/svg"
                xmlns:sketch="http://www.bohemiancoding.com/sketch/ns"
                xmlns:xlink="http://www.w3.org/1999/xlink"
              >
                <title />
                <desc />
                <defs />
                <g
                  fill="none"
                  fill-rule="evenodd"
                  id="Page-1"
                  stroke="none"
                  stroke-width="1"
                >
                  <g
                    fill="#000000"
                    id="Core"
                    transform="translate(-5.000000, -465.000000)"
                  >
                    <g
                      id="swap-vert"
                      transform="translate(5.000000, 465.000000)"
                    >
                      <path
                        d="M11,14 L11,7 L9,7 L9,14 L6,14 L10,18 L14,14 L11,14 L11,14 Z M4,0 L0,4 L3,4 L3,11 L5,11 L5,4 L8,4 L4,0 L4,0 Z"
                        id="Shape"
                      />
                    </g>
                  </g>
                </g>
              </svg>
              <span class="text-xs uppercase">{{ sortOrder }}</span>
            </button>
          </div>
        </div>
        <div class="text-white flex flex-col gap-2 flex-1">
          <div
            v-for="(joke, index) in sliceJokes"
            :key="index"
            class="bg-[#51171c] text-sm p-4 rounded flex flex-col lg:flex-row"
          >
            <div class="flex-1 text-xs lg:pr-4">
              <div class="pb-1 font-bold uppercase flex justify-between">
                <div class="flex gap-2 items-center">
                  <div v-if="joke.generate == 'manual'">
                    <svg
                      width="26"
                      viewBox="0 0 256 256"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <rect fill="none" height="256" width="256" />
                      <path
                        fill="#FFFFFF"
                        d="M188,84a28.2,28.2,0,0,0-12,2.7V52a28.1,28.1,0,0,0-28-28,27.8,27.8,0,0,0-13.4,3.4A28,28,0,0,0,80,36v6.7A28,28,0,0,0,40,68v84a88,88,0,0,0,176,0V112A28.1,28.1,0,0,0,188,84Zm12,68a72,72,0,0,1-144,0V68a12,12,0,0,1,24,0v44a8,8,0,0,0,16,0V36a12,12,0,0,1,24,0v68a8,8,0,0,0,16,0V52a12,12,0,0,1,24,0v72.7A48,48,0,0,0,120,172a8,8,0,0,0,16,0,32.1,32.1,0,0,1,32-32,8,8,0,0,0,8-8V112a12,12,0,0,1,24,0Z"
                      />
                    </svg>
                  </div>
                  <div v-else>
                    <svg
                      width="18px"
                      data-name="Layer 1"
                      id="Layer_1"
                      viewBox="0 0 512 512"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        fill="#FFFFFF"
                        d="M335,156.17H177A20.85,20.85,0,0,0,156.17,177V335A20.85,20.85,0,0,0,177,355.83H335A20.85,20.85,0,0,0,355.83,335V177A20.85,20.85,0,0,0,335,156.17ZM346,335a11,11,0,0,1-11,11H177a11,11,0,0,1-11-11V177a11,11,0,0,1,11-11H335a11,11,0,0,1,11,11Z"
                      />
                      <path
                        fill="#FFFFFF"
                        d="M172,140.4H340a4.93,4.93,0,0,0,0-9.86H323.83V88.41a4.93,4.93,0,0,0-9.86,0v42.13H292V66.28a4.93,4.93,0,0,0-9.86,0v64.26h-22V88.41a4.93,4.93,0,0,0-9.86,0v42.13h-22V66.28a4.93,4.93,0,0,0-9.86,0v64.26h-22V88.41a4.93,4.93,0,0,0-9.86,0v42.13H172a4.93,4.93,0,1,0,0,9.86Z"
                      />
                      <path
                        fill="#FFFFFF"
                        d="M340,371.6H172a4.93,4.93,0,0,0,0,9.86h16.18v42.13a4.93,4.93,0,0,0,9.86,0V381.46h22v64.26a4.93,4.93,0,0,0,9.86,0V381.46h22v42.13a4.93,4.93,0,0,0,9.86,0V381.46h22v64.26a4.93,4.93,0,0,0,9.86,0V381.46h22v42.13a4.93,4.93,0,0,0,9.86,0V381.46H340a4.93,4.93,0,1,0,0-9.86Z"
                      />
                      <path
                        fill="#FFFFFF"
                        d="M445.71,282.1H381.45v-22H423.6a4.93,4.93,0,0,0,0-9.85H381.45v-22h64.26a4.93,4.93,0,1,0,0-9.85H381.45v-22H423.6a4.93,4.93,0,0,0,0-9.85H381.45V172a4.93,4.93,0,0,0-9.86,0V340a4.93,4.93,0,0,0,9.86,0V323.83H423.6a4.93,4.93,0,0,0,0-9.85H381.45V292h64.26a4.93,4.93,0,1,0,0-9.85Z"
                      />
                      <path
                        fill="#FFFFFF"
                        d="M135.47,167.06a4.92,4.92,0,0,0-4.93,4.92v16.19H88.4a4.93,4.93,0,0,0,0,9.85h42.14v22H66.29a4.93,4.93,0,1,0,0,9.85h64.25v22H88.4a4.93,4.93,0,0,0,0,9.85h42.14v22H66.29a4.93,4.93,0,1,0,0,9.85h64.25v22H88.4a4.93,4.93,0,0,0,0,9.85h42.14V340a4.93,4.93,0,0,0,9.85,0V172A4.92,4.92,0,0,0,135.47,167.06Z"
                      />
                      <path
                        fill="#FFFFFF"
                        d="M241.79,207.56c-1.38-3.93-7.9-3.93-9.29,0l-22,62.38-2.45,6.95,0,.07-8.52,24.2a4.91,4.91,0,0,0,3,6.28,4.81,4.81,0,0,0,1.64.29,4.94,4.94,0,0,0,4.65-3.29l7.39-21h41.9l7.4,21a4.93,4.93,0,0,0,9.29-3.28Zm-22.11,66,3.26-9.24a.56.56,0,0,1,0-.12L237.15,224l17.47,49.58Z"
                      />
                      <path
                        fill="#FFFFFF"
                        d="M307.84,204.27a4.93,4.93,0,0,0-4.93,4.93v93.6a4.93,4.93,0,1,0,9.85,0V209.2A4.93,4.93,0,0,0,307.84,204.27Z"
                      />
                    </svg>
                  </div>
                  {{ joke.type }}
                </div>
                <div
                  class="flex flex-row gap-0 justify-center items-center px-2"
                >
                  <button
                    class="flex gap-2 items-center border py-1 px-4 rounded-l-md"
                    @click="qualifyJoke(joke.joke_uuid, 'ok')"
                  >
                    <svg
                      height="15px"
                      version="1.1"
                      viewBox="0 0 22 20"
                      width="15px"
                      xmlns="http://www.w3.org/2000/svg"
                      xmlns:sketch="http://www.bohemiancoding.com/sketch/ns"
                      xmlns:xlink="http://www.w3.org/1999/xlink"
                    >
                      <title />
                      <desc />
                      <defs />
                      <g
                        fill="none"
                        fill-rule="evenodd"
                        id="Page-1"
                        stroke="none"
                        stroke-width="1"
                      >
                        <g
                          fill="#f5f5f5"
                          id="Core"
                          transform="translate(-295.000000, -464.000000)"
                        >
                          <g
                            id="thumb-up"
                            transform="translate(295.000000, 464.000000)"
                          >
                            <path
                              d="M0,20 L4,20 L4,8 L0,8 L0,20 L0,20 Z M22,9 C22,7.9 21.1,7 20,7 L13.7,7 L14.7,2.4 L14.7,2.1 C14.7,1.7 14.5,1.3 14.3,1 L13.2,0 L6.6,6.6 C6.2,6.9 6,7.4 6,8 L6,18 C6,19.1 6.9,20 8,20 L17,20 C17.8,20 18.5,19.5 18.8,18.8 L21.8,11.7 C21.9,11.5 21.9,11.2 21.9,11 L21.9,9 L22,9 C22,9.1 22,9 22,9 L22,9 Z"
                              id="Shape"
                            />
                          </g>
                        </g>
                      </g>
                    </svg>
                    <span>{{ joke.qualify_ok || 0 }} </span>
                  </button>
                  <button
                    class="flex gap-2 items-center border rounded-r-md py-1 px-4"
                    @click="qualifyJoke(joke.joke_uuid, 'nok')"
                  >
                    <svg
                      height="15px"
                      version="1.1"
                      viewBox="0 0 22 20"
                      width="15px"
                      xmlns="http://www.w3.org/2000/svg"
                      xmlns:sketch="http://www.bohemiancoding.com/sketch/ns"
                      xmlns:xlink="http://www.w3.org/1999/xlink"
                    >
                      <title />
                      <desc />
                      <defs />
                      <g
                        fill="none"
                        fill-rule="evenodd"
                        id="Page-1"
                        stroke="none"
                        stroke-width="1"
                      >
                        <g
                          fill="#FFFFFF"
                          id="Core"
                          transform="translate(-253.000000, -464.000000)"
                        >
                          <g
                            id="thumb-down"
                            transform="translate(253.000000, 464.000000)"
                          >
                            <path
                              d="M14,0 L5,0 C4.2,0 3.5,0.5 3.2,1.2 L0.2,8.3 C0.1,8.5 0,8.7 0,9 L0,10.9 L0,11 C0,12.1 0.9,13 2,13 L8.3,13 L7.3,17.6 L7.3,17.9 C7.3,18.3 7.5,18.7 7.7,19 L8.8,20 L15.4,13.4 C15.8,13 16,12.5 16,12 L16,2 C16,0.9 15.1,0 14,0 L14,0 Z M18,0 L18,12 L22,12 L22,0 L18,0 L18,0 Z"
                              id="Shape"
                            />
                          </g>
                        </g>
                      </g>
                    </svg>
                    <span>{{ joke.qualify_nok || 0 }} </span>
                  </button>
                </div>
              </div>

              <div class="flex flex-row gap-1">
                <span class="font-bold">Setup:</span>
                <span>{{ joke.setup }}</span>
              </div>
              <div class="flex flex-row gap-1">
                <span class="font-bold">Punchline</span>
                <span>{{ joke.punchline }}</span>
              </div>
            </div>
            <div
              class="flex items-center gap-1 lg:gap-2 justify-center pt-2 lg:pt-0"
            >
              <button
                class="bg-[#817b71] text-white px-4 py-2 text-xs rounded-full"
                @click="editJokeModal(joke)"
              >
                <svg
                  height="18px"
                  version="1.1"
                  viewBox="0 0 18 18"
                  width="18px"
                  xmlns="http://www.w3.org/2000/svg"
                  xmlns:sketch="http://www.bohemiancoding.com/sketch/ns"
                  xmlns:xlink="http://www.w3.org/1999/xlink"
                >
                  <title />
                  <desc />
                  <defs />
                  <g
                    fill="none"
                    fill-rule="evenodd"
                    id="Page-1"
                    stroke="none"
                    stroke-width="1"
                  >
                    <g
                      fill="#FFFFFF"
                      id="Core"
                      transform="translate(-213.000000, -129.000000)"
                    >
                      <g
                        id="create"
                        transform="translate(213.000000, 129.000000)"
                      >
                        <path
                          d="M0,14.2 L0,18 L3.8,18 L14.8,6.9 L11,3.1 L0,14.2 L0,14.2 Z M17.7,4 C18.1,3.6 18.1,3 17.7,2.6 L15.4,0.3 C15,-0.1 14.4,-0.1 14,0.3 L12.2,2.1 L16,5.9 L17.7,4 L17.7,4 Z"
                          id="Shape"
                        />
                      </g>
                    </g>
                  </g>
                </svg>
              </button>

              <button
                class="bg-[#817b71] text-white px-4 py-2 text-xs rounded-full"
                @click="speechText(joke)"
              >
                <svg
                  height="19px"
                  id="Layer_1"
                  style="enable-background: new 0 0 512 512"
                  version="1.1"
                  viewBox="0 0 512 512"
                  width="19px"
                  fill="#FFFFFF"
                  xml:space="preserve"
                  xmlns="http://www.w3.org/2000/svg"
                  xmlns:xlink="http://www.w3.org/1999/xlink"
                >
                  <path
                    d="M405.2,232.9L126.8,67.2c-3.4-2-6.9-3.2-10.9-3.2c-10.9,0-19.8,9-19.8,20H96v344h0.1c0,11,8.9,20,19.8,20  c4.1,0,7.5-1.4,11.2-3.4l278.1-165.5c6.6-5.5,10.8-13.8,10.8-23.1C416,246.7,411.8,238.5,405.2,232.9z"
                  />
                </svg>
              </button>
              <button
                class="bg-[#817b71] text-white px-4 py-2 text-xs rounded-full flex items-center flex-row gap-2"
                @click="generateAudioJoke(joke)"
                v-if="!joke.audio_url"
              >
                <svg
                  height="18px"
                  version="1.1"
                  viewBox="0 0 30 26"
                  width="18px"
                  xmlns="http://www.w3.org/2000/svg"
                  xmlns:xlink="http://www.w3.org/1999/xlink"
                >
                  <title />
                  <desc />
                  <defs />
                  <g
                    fill="none"
                    fill-rule="evenodd"
                    id="Music"
                    stroke="none"
                    stroke-width="1"
                  >
                    <g
                      id="Icons"
                      transform="translate(-403.000000, -210.000000)"
                    >
                      <g
                        id="Musical-note-2"
                        transform="translate(406.000000, 210.000000)"
                      >
                        <rect
                          fill="#FFFFFF"
                          height="21"
                          id="Rectangle"
                          rx="1.5"
                          width="3"
                          x="8"
                          y="0"
                        />
                        <circle
                          cx="4"
                          cy="19"
                          id="Oval-2"
                          r="5.5"
                          stroke="#FFFFFF"
                          stroke-width="3"
                        />
                        <rect
                          fill="#FFFFFF"
                          height="21"
                          id="Rectangle"
                          rx="1.5"
                          width="3"
                          x="24"
                          y="0"
                        />
                        <circle
                          cx="20"
                          cy="19"
                          id="Oval-2"
                          r="5.5"
                          stroke="#FFFFFF"
                          stroke-width="3"
                        />
                        <rect
                          fill="#FFFFFF"
                          height="19"
                          id="Rectangle"
                          rx="1.5"
                          transform="translate(17.500000, 1.500000) rotate(90.000000) translate(-17.500000, -1.500000) "
                          width="3"
                          x="16"
                          y="-8"
                        />
                      </g>
                    </g>
                  </g>
                </svg>
                <span class="hidden lg:flex">Generate</span>
                <span class="flex lg:hidden">Gen</span>
              </button>
              <a
                class="bg-[#2e8b57] text-white px-4 py-2 text-xs rounded-full flex items-center flex-row gap-2"
                :href="joke.audio_url"
                target="_blank"
                v-else
              >
                <svg
                  height="18px"
                  version="1.1"
                  viewBox="0 0 30 26"
                  width="18px"
                  xmlns="http://www.w3.org/2000/svg"
                  xmlns:xlink="http://www.w3.org/1999/xlink"
                >
                  <title />
                  <desc />
                  <defs />
                  <g
                    fill="none"
                    fill-rule="evenodd"
                    id="Music"
                    stroke="none"
                    stroke-width="1"
                  >
                    <g
                      id="Icons"
                      transform="translate(-403.000000, -210.000000)"
                    >
                      <g
                        id="Musical-note-2"
                        transform="translate(406.000000, 210.000000)"
                      >
                        <rect
                          fill="#FFFFFF"
                          height="21"
                          id="Rectangle"
                          rx="1.5"
                          width="3"
                          x="8"
                          y="0"
                        />
                        <circle
                          cx="4"
                          cy="19"
                          id="Oval-2"
                          r="5.5"
                          stroke="#FFFFFF"
                          stroke-width="3"
                        />
                        <rect
                          fill="#FFFFFF"
                          height="21"
                          id="Rectangle"
                          rx="1.5"
                          width="3"
                          x="24"
                          y="0"
                        />
                        <circle
                          cx="20"
                          cy="19"
                          id="Oval-2"
                          r="5.5"
                          stroke="#FFFFFF"
                          stroke-width="3"
                        />
                        <rect
                          fill="#FFFFFF"
                          height="19"
                          id="Rectangle"
                          rx="1.5"
                          transform="translate(17.500000, 1.500000) rotate(90.000000) translate(-17.500000, -1.500000) "
                          width="3"
                          x="16"
                          y="-8"
                        />
                      </g>
                    </g>
                  </g>
                </svg>
                <span class="hidden lg:flex">Download</span>
                <span class="flex lg:hidden">Down</span>
              </a>
              <button
                class="bg-[#817b71] text-white px-4 py-2 text-xs rounded-full flex items-center flex-row gap-2"
                v-if="!joke.image_url"
                @click="generateImageJoke(joke)"
              >
                <svg
                  height="18px"
                  id="Layer_1"
                  style="enable-background: new 0 0 512 512"
                  version="1.1"
                  viewBox="0 0 512 512"
                  width="18px"
                  xml:space="preserve"
                  xmlns="http://www.w3.org/2000/svg"
                  xmlns:xlink="http://www.w3.org/1999/xlink"
                >
                  <g>
                    <path
                      d="M368,224c26.5,0,48-21.5,48-48c0-26.5-21.5-48-48-48c-26.5,0-48,21.5-48,48C320,202.5,341.5,224,368,224z"
                      fill="#FFF"
                    />
                    <path
                      d="M452,64H60c-15.6,0-28,12.7-28,28.3v327.4c0,15.6,12.4,28.3,28,28.3h392c15.6,0,28-12.7,28-28.3V92.3   C480,76.7,467.6,64,452,64z M348.9,261.7c-3-3.5-7.6-6.2-12.8-6.2c-5.1,0-8.7,2.4-12.8,5.7l-18.7,15.8c-3.9,2.8-7,4.7-11.5,4.7   c-4.3,0-8.2-1.6-11-4.1c-1-0.9-2.8-2.6-4.3-4.1L224,215.3c-4-4.6-10-7.5-16.7-7.5c-6.7,0-12.9,3.3-16.8,7.8L64,368.2V107.7   c1-6.8,6.3-11.7,13.1-11.7h357.7c6.9,0,12.5,5.1,12.9,12l0.3,260.4L348.9,261.7z"
                      fill="#FFF"
                    />
                  </g>
                </svg>
                <span class="hidden lg:flex">Generate</span>
                <span class="flex lg:hidden">Gen</span>
              </button>
              <a
                class="bg-[#2e8b57] text-white px-4 py-2 text-xs rounded-full flex items-center flex-row gap-2"
                v-else
                :href="joke.image_url"
                target="_blank"
              >
                <svg
                  height="18px"
                  id="Layer_1"
                  style="enable-background: new 0 0 512 512"
                  version="1.1"
                  viewBox="0 0 512 512"
                  width="18px"
                  xml:space="preserve"
                  xmlns="http://www.w3.org/2000/svg"
                  xmlns:xlink="http://www.w3.org/1999/xlink"
                >
                  <g>
                    <path
                      d="M368,224c26.5,0,48-21.5,48-48c0-26.5-21.5-48-48-48c-26.5,0-48,21.5-48,48C320,202.5,341.5,224,368,224z"
                      fill="#FFF"
                    />
                    <path
                      d="M452,64H60c-15.6,0-28,12.7-28,28.3v327.4c0,15.6,12.4,28.3,28,28.3h392c15.6,0,28-12.7,28-28.3V92.3   C480,76.7,467.6,64,452,64z M348.9,261.7c-3-3.5-7.6-6.2-12.8-6.2c-5.1,0-8.7,2.4-12.8,5.7l-18.7,15.8c-3.9,2.8-7,4.7-11.5,4.7   c-4.3,0-8.2-1.6-11-4.1c-1-0.9-2.8-2.6-4.3-4.1L224,215.3c-4-4.6-10-7.5-16.7-7.5c-6.7,0-12.9,3.3-16.8,7.8L64,368.2V107.7   c1-6.8,6.3-11.7,13.1-11.7h357.7c6.9,0,12.5,5.1,12.9,12l0.3,260.4L348.9,261.7z"
                      fill="#FFF"
                    />
                  </g>
                </svg>
                <span class="hidden lg:flex">Download</span>
                <span class="flex lg:hidden">Down</span>
              </a>
              <button
                class="bg-[#c22929] text-white px-4 py-2 text-xs rounded-full"
                @click="deleteJoke(joke.joke_uuid)"
              >
                <svg
                  height="18px"
                  version="1.1"
                  viewBox="0 0 14 18"
                  width="14px"
                  xmlns="http://www.w3.org/2000/svg"
                  xmlns:sketch="http://www.bohemiancoding.com/sketch/ns"
                  xmlns:xlink="http://www.w3.org/1999/xlink"
                >
                  <title />
                  <desc />
                  <defs />
                  <g
                    fill="none"
                    fill-rule="evenodd"
                    id="Page-1"
                    stroke="none"
                    stroke-width="1"
                  >
                    <g
                      fill="#FFFFFF"
                      id="Core"
                      transform="translate(-299.000000, -129.000000)"
                    >
                      <g
                        id="delete"
                        transform="translate(299.000000, 129.000000)"
                      >
                        <path
                          d="M1,16 C1,17.1 1.9,18 3,18 L11,18 C12.1,18 13,17.1 13,16 L13,4 L1,4 L1,16 L1,16 Z M14,1 L10.5,1 L9.5,0 L4.5,0 L3.5,1 L0,1 L0,3 L14,3 L14,1 L14,1 Z"
                          id="Shape"
                        />
                      </g>
                    </g>
                  </g>
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="bg-[#bc8f8f] w-full px-4 lg:px-0 py-8 flex justify-center">
      <div class="container">
        <span class="text-[#ecdede] text-lg font-bold">Dashboard</span>
        <div class="flex flex-col lg:flex-row gap-2">
          <div
            class="flex flex-col flex-1 bg-[#704949] rounded px-4 py-2 text-white"
          >
            <span class="text-xs text-right uppercase text-green-200"
              >The best joke</span
            >
            <div class="text-sm">
              <div class="flex flex-row gap-1">
                <span class="font-bold">Setup:</span>
                <span>{{ bestJoke.setup }}</span>
              </div>
              <div class="flex flex-row gap-1">
                <span class="font-bold">Punchline</span>
                <span>{{ bestJoke.punchline }}</span>
              </div>
            </div>
          </div>
          <div
            class="flex flex-col flex-1 bg-[#704949] rounded px-4 py-2 text-white"
          >
            <span class="text-xs text-right uppercase text-red-200"
              >The worst joke</span
            >
            <div class="text-sm">
              <div class="flex flex-row gap-1">
                <span class="font-bold">Setup:</span>
                <span>{{ worstJoke.setup }}</span>
              </div>
              <div class="flex flex-row gap-1">
                <span class="font-bold">Punchline</span>
                <span>{{ worstJoke.punchline }}</span>
              </div>
            </div>
          </div>
        </div>
        <div class="grid grid-cols-1 lg:grid-cols-2 pt-4 gap-2">
          <div class="border-2 border-[#704949] rounded p-2 w-full flex flex-col gap-2">
            <span class="text-center text-[#704949] uppercase">Jokes by type</span>
            <Doughnut :labels="categoryJokes" :data="groupJokeByType"  />
          </div>
          <div class="border-2 border-[#704949] rounded p-2 w-full flex flex-col gap-2">
            <span class="text-center text-[#704949] uppercase">Jokes by generate type</span>
            <Doughnut :labels="generateSelectValues" :data="groupJokeByGenerate"  />
          </div>
        </div>
      </div>
    </div>

    <div class="bg-white w-full p-2 flex justify-center">
      <div class="container flex justify-end items-center">
        <span>Developed by</span>
        <img src="./assets/logoajuarez93.jpeg" alt="" class="h-20" />
      </div>
    </div>
    <ModalForm
      ref="modalForm"
      :category-jokes="categoryJokes"
      :joke="currentJoke"
      @close="loadJokes"
    />

    <ModalAI ref="modalAI" @close="loadJokes" />
    <Loader ref="loaderRef" />
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from "vue";
import Paginator from "./components/Paginator.vue";
import ModalForm from "./components/ModalForm.vue";
import ModalAI from "./components/ModalAI.vue";
import Loader from "./components/Loader.vue";
import Doughnut from "./components/Doughnut.vue";

const jokes = ref([]);
const setupText = ref("");
const punchlineText = ref("");
const typeSelect = ref("");
const generateSelect = ref("");
const currentJoke = ref({});

const sortOrder = ref("asc");
const generateSelectValues = ref(["manual", "ai"]);
const currentPage = ref(1);
const itemsPerPage = ref(10);

const modalForm = ref(null);
const modalAI = ref(null);
const loaderRef = ref(null);

function changeOrder() {
  sortOrder.value = sortOrder.value == "asc" ? "desc" : "asc";
}

const filteredJokes = computed(() => {
  return jokes.value
    .filter((joke) =>
      joke.setup.toLowerCase().includes(setupText.value.toLowerCase())
    )
    .filter((joke) =>
      joke.punchline.toLowerCase().includes(punchlineText.value.toLowerCase())
    )
    .filter((joke) =>
      joke.type.toLowerCase().includes(typeSelect.value.toLowerCase())
    )
    .filter((joke) =>
      joke.generate.toLowerCase().includes(generateSelect.value.toLowerCase())
    )
    .sort((a, b) => {
      if (sortOrder.value === "asc") return a.setup.localeCompare(b.setup);
      else return b.setup.localeCompare(a.setup);
    });
});

const sliceJokes = computed(() => {
  let from = 0;
  let to = from + itemsPerPage.value;
  if (currentPage.value != 0) {
    from = (currentPage.value - 1) * itemsPerPage.value;
    to = from + itemsPerPage.value;
  }

  return filteredJokes.value.slice(from, to);
});

const bestJoke = computed(() => {
  return (
    filteredJokes.value.sort((a, b) => b.qualify_ok - a.qualify_ok)[0] || {}
  );
});

const worstJoke = computed(() => {
  return (
    filteredJokes.value.sort((a, b) => b.qualify_nok - a.qualify_nok)[0] || {}
  );
});


const categoryJokes = computed(() => {
  return Array.from(new Set(jokes.value.map((joke) => joke.type)));
});

const groupJokeByType = computed(() => {
  const newRes = [];
  const res =  filteredJokes.value.reduce((acc, joke) => {
    acc[joke.type] = (acc[joke.type] || 0) + 1;
    return acc;
  }, {});
  
  categoryJokes.value.forEach((c) => {
    newRes.push(res[c] || 0)
  })
  return newRes;
});


const groupJokeByGenerate = computed(() => {
  const newRes = [];
  const res =  filteredJokes.value.reduce((acc, joke) => {
    acc[joke.generate] = (acc[joke.generate] || 0) + 1;
    return acc;
  }, {});
  
  generateSelectValues.value.forEach((c) => {
    newRes.push(res[c] || 0)
  })
  return newRes;
});

function newJokeModal() {
  currentJoke.value = {};
  modalForm.value.open();
}

function editJokeModal(j) {
  currentJoke.value = j;
  modalForm.value.open();
}

function openModalJokeAI() {
  modalAI.value.open();
}

function clearFilter() {
  setupText.value = "";
  punchlineText.value = "";
  typeSelect.value = "";
  generateSelect.value = "";
}

function speechText(j) {
  let speech = new SpeechSynthesisUtterance(j.setup);
  speech.lang = "en-US";
  window.speechSynthesis.speak(speech);
  speech.onend = () => {
    setTimeout(speakNextPart, 1500);
  };

  function speakNextPart() {
    speech = new SpeechSynthesisUtterance(j.punchline);
    speech.lang = "en-US";
    window.speechSynthesis.speak(speech);
  }
}

async function loadJokes() {
  try {
    loaderRef.value.open();
    const response = await fetch(
      "joke-funny-get-data.py"
    );
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
    const data = await response.json();
    loaderRef.value.close();
    // Update your jokes array with the new jokes
    jokes.value = data;
  } catch (error) {
    console.error("Failed to fetch jokes:", error);
  }
}

async function deleteJoke(joke_uuid) {
  try {
    const jokeDelete = {
      joke_uuid,
    };
    loaderRef.value.open();

    const myHeaders = new Headers();

    const requestOptions = {
      method: "POST",
      headers: myHeaders,
      body: JSON.stringify(jokeDelete),
      redirect: "follow",
    };

    const response = await fetch(
      "joke-funny-add-delete.py",
      requestOptions
    );
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    loaderRef.value.close();

    await loadJokes();
  } catch (error) {
    console.error("Failed to fetch jokes:", error);
  }
}

async function generateAudioJoke(joke) {
  try {
    loaderRef.value.open();

    const myHeaders = new Headers();

    const requestOptions = {
      method: "POST",
      headers: myHeaders,
      body: JSON.stringify(joke),
      redirect: "follow",
    };

    const response = await fetch(
      "joke-funny-generate-audio.py",
      requestOptions
    );
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    loaderRef.value.close();

    await loadJokes();
  } catch (error) {
    console.error("Failed to fetch jokes:", error);
  }
}

async function generateImageJoke(joke) {
  try {
    loaderRef.value.open();

    const myHeaders = new Headers();

    const requestOptions = {
      method: "POST",
      headers: myHeaders,
      body: JSON.stringify(joke),
      redirect: "follow",
    };

    const response = await fetch(
      "joke-funny-generate-image.py",
      requestOptions
    );
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    loaderRef.value.close();

    await loadJokes();
  } catch (error) {
    console.error("Failed to fetch jokes:", error);
  }
}

async function qualifyJoke(joke_uuid, qualify) {
  try {
    const jokeQualify = {
      joke_uuid,
      qualify,
    };

    loaderRef.value.open();

    const myHeaders = new Headers();

    const requestOptions = {
      method: "POST",
      headers: myHeaders,
      body: JSON.stringify(jokeQualify),
      redirect: "follow",
    };

    const response = await fetch(
      "joke-funny-add-qualify.py/",
      requestOptions
    );
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    loaderRef.value.close();

    await loadJokes();
  } catch (error) {
    console.error("Failed to fetch jokes:", error);
  }
}

const handlePageChange = (page) => {
  currentPage.value = page;
};
onMounted(() => {
  loadJokes();
});

// Add logic for pagination (slicing the jokes array) in your template or script
</script>
