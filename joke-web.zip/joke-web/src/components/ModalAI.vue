<template>
  <div
    v-if="isOpen"
    class="fixed z-10 bg-black h-screen w-screen top-0 bg-opacity-50 flex items-center justify-center"
  >
    <!-- Modal Content -->
    <div class="bg-[#ede6db] p-4 rounded w-3/4 lg:w-1/3">
      <div class="flex justify-between">
        <h2>AI Joke</h2>
        <button @click="close">
          <svg
            height="24px"
            id="Layer_1"
            style="enable-background: new 0 0 512 512"
            version="1.1"
            viewBox="0 0 512 512"
            width="24px"
            xml:space="preserve"
            xmlns="http://www.w3.org/2000/svg"
            xmlns:xlink="http://www.w3.org/1999/xlink"
          >
            <path
              d="M437.5,386.6L306.9,256l130.6-130.6c14.1-14.1,14.1-36.8,0-50.9c-14.1-14.1-36.8-14.1-50.9,0L256,205.1L125.4,74.5  c-14.1-14.1-36.8-14.1-50.9,0c-14.1,14.1-14.1,36.8,0,50.9L205.1,256L74.5,386.6c-14.1,14.1-14.1,36.8,0,50.9  c14.1,14.1,36.8,14.1,50.9,0L256,306.9l130.6,130.6c14.1,14.1,36.8,14.1,50.9,0C451.5,423.4,451.5,400.6,437.5,386.6z"
            />
          </svg>
        </button>
      </div>
      <template v-if="jokesAI.length > 0">
        <div
          class="text-white flex flex-col gap-2 flex-1 h-96 overflow-y-auto my-2"
        >
          <div
            v-for="(joke, index) in jokesAI"
            :key="index"
            class="bg-[#51171c] text-xs p-4 rounded flex flex-col lg:flex-row"
          >
            <div class="flex flex-row gap-1">
              <span class="font-bold">Setup:</span>
              <span>{{ joke.setup }}</span>
            </div>
            <div class="flex flex-row gap-1">
              <span class="font-bold">Punchline</span>
              <span>{{ joke.punchline }}</span>
            </div>
          </div>
        </div>

        <div class="flex justify-end gap-2">
          <button
            class="bg-[#c22929] text-white px-4 py-2 text-xs rounded-full"
            @click="close"
          >
            Close
          </button>
          <button
            class="bg-[#9d5353] text-white px-4 py-2 text-xs rounded-full"
            @click="save"
          >
            Save All
          </button>
        </div>
      </template>
      <template v-else>
        <div class="p-4 flex flex-col justify-center items-center">
          <img src="../assets/joke.png" alt="Joke Funny" class="h-12 w-12" />
          Generating random jokes funny, please wait!
        </div>
      </template>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import { toast } from "vue3-toastify";
import "vue3-toastify/dist/index.css";

const isOpen = ref(false);
const jokesAI = ref([]);

function open() {
  isOpen.value = true;
  jokesAI.value = [];
  loadAIJokes();
}

function close() {
  isOpen.value = false;
}

const emit = defineEmits(["close"]);

async function loadAIJokes() {
  try {
    const response = await fetch(
      "joke-funny-get-generate-ai.py"
    );
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
    const data = await response.json();
    jokesAI.value = data;
  } catch (error) {
    console.error("Failed to fetch jokes:", error);
  }
}

async function save() {
  jokesAI.value.forEach(async (j) => {
    const jokeSave = {
      setup: j.setup,
      punchline: j.punchline,
      type: j.type ? j.type : "general",
      generate: "ai",
    };

    const myHeaders = new Headers();

    const requestOptions = {
      method: "POST",
      headers: myHeaders,
      body: JSON.stringify(jokeSave),
      redirect: "follow",
    };
    const response = await fetch(
      "joke-funny-add-data.py",
      requestOptions
    );
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
  });

  toast("Saved successfully", {
    autoClose: 1000,
  });
  close();
  emit("close", {});
}

defineExpose({ open });
</script>
