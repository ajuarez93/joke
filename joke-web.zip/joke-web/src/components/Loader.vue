<template>
  <div
    v-if="isOpen"
    class="fixed h-screen w-screen bg-white bg-opacity-50 z-20 top-0 flex items-center justify-center"
  >
    <div class="flex justify-center items-center gap-2">
      <img src="../assets/joke.png" alt="Joke Funny" />
      <span class="text-lg font-bold"> Procesing Data</span>
    </div>
    <!-- Modal Content -->
  </div>
</template>

<script>
import { ref } from "vue";

export default {
  setup() {
    const isOpen = ref(false);
    const input1 = ref("");
    const input2 = ref("");
    const selectedOption = ref("");
    const options = ref([
      { text: "Option 1", value: "1" },
      { text: "Option 2", value: "2" },
      { text: "Option 3", value: "3" },
    ]);

    function open() {
      isOpen.value = true;
    }

    function close() {
      isOpen.value = false;
    }

    function confirm() {
      // Handle the confirmation logic here
      console.log("Confirmed", {
        input1: input1.value,
        input2: input2.value,
        selectedOption: selectedOption.value,
      });
      close(); // Close modal after confirm
    }

    // Expose to template
    return {
      isOpen,
      open,
      close,
      confirm,
      input1,
      input2,
      selectedOption,
      options,
    };
  },
};
</script>
