<template>
  <div
    v-if="isOpen"
    class="fixed z-10 bg-black h-screen w-screen top-0 bg-opacity-50 flex items-center justify-center"
  >
    <!-- Modal Content -->
    <div class="bg-[#ede6db] p-4 rounded w-1/2 lg:w-1/3">
      <div class="flex justify-between">
        <h2>Add / Edit Joke</h2>
        <button @click="close">
          <svg
            height="24px"
            id="Layer_1"
            style="enable-background: new 0 0 512 512"
            version="1.1"
            viewBox="0 0 512 512"
            width="24px"
            xml:space="preserve"
            xmlns="http://www.w3.org/2000/svg"
            xmlns:xlink="http://www.w3.org/1999/xlink"
          >
            <path
              d="M437.5,386.6L306.9,256l130.6-130.6c14.1-14.1,14.1-36.8,0-50.9c-14.1-14.1-36.8-14.1-50.9,0L256,205.1L125.4,74.5  c-14.1-14.1-36.8-14.1-50.9,0c-14.1,14.1-14.1,36.8,0,50.9L205.1,256L74.5,386.6c-14.1,14.1-14.1,36.8,0,50.9  c14.1,14.1,36.8,14.1,50.9,0L256,306.9l130.6,130.6c14.1,14.1,36.8,14.1,50.9,0C451.5,423.4,451.5,400.6,437.5,386.6z"
            />
          </svg>
        </button>
      </div>
      <div class="py-4 flex flex-col gap-2">
        <div class="flex flex-col">
          <label for="Setup" class="text-sm text-black">Setup</label>
          <input
            v-model="setupText"
            name="Setup"
            type="text"
            class="w-full text-sm rounded py-1 px-2"
          />
        </div>
        <div class="flex flex-col">
          <label for="Punchline" class="text-sm text-black">Punchline</label>
          <input
            v-model="punchlineText"
            name="Punchline"
            type="text"
            class="w-full text-sm rounded py-1 px-2"
          />
        </div>
        <div class="flex flex-col">
          <label for="type " class="text-sm text-black">Type</label>
          <select v-model="typeSelect" class="w-full text-sm rounded py-1 px-2">
            <option v-for="c in categoryJokes" :value="c">{{ c }}</option>
          </select>
        </div>
      </div>
      <div class="flex justify-end gap-2">
        <button
          class="bg-[#c22929] text-white px-4 py-2 text-xs rounded-full"
          @click="close"
        >
          Close
        </button>
        <button
          class="bg-[#9d5353] text-white px-4 py-2 text-xs rounded-full"
          @click="confirm"
        >
          Confirm
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, watchEffect } from "vue";
import { toast } from "vue3-toastify";
import "vue3-toastify/dist/index.css";

const isOpen = ref(false);
const setupText = ref("");
const punchlineText = ref("");
const typeSelect = ref("");
const props = defineProps({
  categoryJokes: Array,
  joke: Object,
});

const emit = defineEmits(["close"]);

function open() {
  isOpen.value = true;
}

function close() {
  isOpen.value = false;
}

function validateData(d) {
  if (!d.setup) {
    return {
      status: false,
      message: "You need to add the 'Setup', before saving",
    };
  }
  if (!d.punchline) {
    return {
      status: false,
      message: "You need to add the 'Punchline', before saving",
    };
  }
  if (!d.type) {
    return {
      status: false,
      message: "You need to add the 'Type', before saving",
    };
  }
  return {
    status: true,
    message: "",
  };
}

async function confirm() {
  const jokeSave = {
    ...props.joke,
    ...{
      setup: setupText.value,
      punchline: punchlineText.value,
      type: typeSelect.value,
      generate: "manual",
    },
  };
  const res = validateData(jokeSave);
  if (res.status) {
    // Handle the confirmation logic here
    try {
      const myHeaders = new Headers();

      const requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: JSON.stringify(jokeSave),
        redirect: "follow",
      };
      const response = await fetch(
        "joke-funny-add-data.py",
        requestOptions
      );
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      toast("Saved successfully", {
        autoClose: 1000,
      });
      close();
      emit("close", {});
    } catch (error) {
      toast(error, {
        type: "error",
        autoClose: 1000,
      });
      console.error("Failed to fetch jokes:", error);
    }
  } else {
    toast(res.message, {
      type: "error",
      autoClose: 1000,
    });
  }
}

watchEffect(() => {
  if (props.joke.setup) {
    setupText.value = props.joke.setup;
  }
  if (props.joke.punchline) {
    punchlineText.value = props.joke.punchline;
  }
  if (props.joke.type) {
    typeSelect.value = props.joke.type;
  }
});

defineExpose({ open });
</script>
