<template>
  <DoughnutChart :chartData="testData" />
</template>

<script setup lang="ts">
import { ref, defineProps, watchEffect } from "vue";
import { DoughnutChart } from "vue-chart-3";
import { Chart, registerables } from "chart.js";

// Registering chart.js components
Chart.register(...registerables);

// Define props
const props = defineProps({
  labels: {
    type: Array,
    default: () => [],
  },
  data: {
    type: Array,
    default: () => [],
  },
  backgroundColor: {
    type: Array,
    default: () => [
      "#00002c",
      "#011d45",
      "#073460",
      "#0f4c7c",
      "#2b679b",
      "#4f85bb",
      "#71a4dc",
      "#92c4fe",
    ],
  },
});

// Create testData for the DoughnutChart
const testData = ref({
  labels: props.labels,
  datasets: [
    {
      data: props.data,
      backgroundColor: props.backgroundColor,
    },
  ],
});

watchEffect(() => {
  if (props.data.length > 0) {
    testData.value = {
      labels: props.labels,
      datasets: [
        {
          data: props.data,
          backgroundColor: props.backgroundColor,
        },
      ],
    };
  }
});
</script>
