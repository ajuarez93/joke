<template>
    <div class="flex flex-row gap-2 text-xs p-2">
      <button class="border border-black px-2 rounded" @click="goToPrevPage" :disabled="currentPage <= 1">
        Previous
      </button>
      <span>Page {{ currentPage }} of {{ totalPages }}</span>
      <button class="border border-black px-2 rounded" @click="goToNextPage" :disabled="currentPage >= totalPages">
        Next
      </button>
    </div>
  </template>
  
  <script setup>
  import { computed, ref, watchEffect } from 'vue';
  
  const props = defineProps({
    totalItems: Number,
    itemsPerPage: Number,
  });
  
  const emit = defineEmits(['page-changed']);
  
  const currentPage = ref(1);
  
  const totalPages = computed(() => {
    return Math.ceil(props.totalItems / props.itemsPerPage);
  });
  
  const goToPrevPage = () => {
    if (currentPage.value > 1) {
      currentPage.value--;
      emit('page-changed', currentPage.value);
    }
  };
  
  const goToNextPage = () => {
    if (currentPage.value < totalPages.value) {
      currentPage.value++;
      emit('page-changed', currentPage.value);
    }
  };
  
  watchEffect(() => {
    if (currentPage.value != 0 && totalPages.value != 0 && currentPage.value > totalPages.value) {
      currentPage.value = totalPages.value;
      emit('page-changed', currentPage.value);
    }
  });
  </script>
  
  