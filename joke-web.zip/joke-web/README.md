# JOKE-WEB

---

Web application where you can find the best jokes for programmers. Here you can:

- Create jokes
- Use AI to generate jokes
- Edit jokes
- Play jokes
- Generate and download audio to share
- Generate and download an image to share
- Delete jokes
- Rate the joke as good or bad

---

## Built with Vue 3 and Vite

This application is developed using Vue 3, the progressive JavaScript framework for building user interfaces. Vue 3 brings enhanced performance, improved composition API, and better TypeScript integration, making our application more efficient and developer-friendly.

We use Vite as our build tool, which offers a fast development environment with features such as hot module replacement (HMR) and efficient bundling for production. Vite's design leverages modern JavaScript features and aims to provide a leaner and faster development experience.

### Getting Started with Development

To run this project locally, follow these steps:

1. **Clone the repository**:

   ```
   git clone [repository URL]
   ```

2. **Navigate to the project directory**:

   ```
   cd [project directory]
   ```

3. **Install dependencies**:

   ```
   npm install
   ```

4. **Run the development server**:

   ```
   npm run dev
   ```

   This command starts the local development server using Vite. Open [http://localhost:3000](http://localhost:3000) to view the application in your browser.

For more detailed documentation on Vue 3 and Vite, visit their respective official documentation:

- [Vue 3 Documentation](https://v3.vuejs.org/)
- [Vite Documentation](https://vitejs.dev/)

---

### Amplify

This application is hosted on Amplify. To get started with the process, you can follow these instructions:

1. **Set up your environment**: Ensure you have Node.js installed on your machine. Amplify supports Node.js versions 12 and above.

2. **Install the Amplify CLI**: Open your terminal (command prompt or PowerShell on Windows) and install the Amplify Command Line Interface (CLI) by running `npm install -g @aws-amplify/cli`.

3. **Configure Amplify**: Once the installation is complete, configure Amplify by running `amplify configure`. This command will guide you through the initial setup, including the creation of an AWS account if you do not already have one.

4. **Initialize Amplify in your project**: Navigate to the root directory of your project in the terminal and run `amplify init`. This command initializes a new Amplify project and you will be prompted to answer questions about your project's configuration.

5. **Add hosting**: To add hosting to your Amplify project, run `amplify add hosting`. This will allow you to host your web application on AWS.

6. **Deploy your application**: Finally, deploy your application by running `amplify publish`. This command builds your web application and deploys it to AWS Amplify Hosting.

For more detailed instructions and additional options, please refer to the [official Amplify documentation](https://docs.amplify.aws/vue/start/getting-started/introduction/).

---

## Libraries and Assets

In this project, we utilize a range of libraries and assets to enhance the user experience and functionality of our web application:

- **Icons**: From Iconfinder. We use various icons to improve the UI's visual appeal and user navigation.
- **CSS Framework**: Tailwind CSS. This utility-first CSS framework is used for designing custom user interfaces with speed and efficiency.
- **Charts**: Chart.js and vue-chart-3. These libraries are employed to render interactive and responsive charts for a better representation of data.
- **Toast Notifications**: vue3-toastify. This Vue 3 compatible library provides an easy way to display toast notifications, enhancing the feedback experience for actions taken by users.
- **Analytics**: Firebase Analytics. We leverage Firebase Analytics to understand user behavior, app usage patterns, and improve app performance based on collected data.

---
